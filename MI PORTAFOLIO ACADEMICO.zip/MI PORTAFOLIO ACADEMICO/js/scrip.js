let archivos = [];
let archivoEditando = null;

function subirArchivo() {
  const input = document.getElementById('archivoInput');
  const archivo = input.files[0];
  if (archivo) {
    archivos.push({ nombre: archivo.name });
    input.value = '';
    mostrarArchivos();
  }
}

function mostrarArchivos() {
  const lista = document.getElementById('listaArchivos');
  lista.innerHTML = '';

  archivos.forEach((archivo, index) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <i class="fas fa-file-alt"></i> ${archivo.nombre}
      <button onclick="editarArchivo(${index})"><i class="fas fa-edit"></i></button>
      <button onclick="eliminarArchivo(${index})"><i class="fas fa-trash"></i></button>
    `;
    lista.appendChild(li);
  });
}

function editarArchivo(index) {
  archivoEditando = index;
  document.getElementById('nuevoNombre').value = archivos[index].nombre;
  document.getElementById('modalEditar').style.display = 'block';
}

function eliminarArchivo(index) {
  if (confirm("¿Estás seguro de que deseas eliminar este archivo?")) {
    archivos.splice(index, 1);
    mostrarArchivos();
  }
}

function guardarEdicion() {
  const nuevoNombre = document.getElementById('nuevoNombre').value.trim();
  if (nuevoNombre) {
    archivos[archivoEditando].nombre = nuevoNombre;
    cerrarModal();
    mostrarArchivos();
  }
}

function cerrarModal() {
  document.getElementById('modalEditar').style.display = 'none';
  archivoEditando = null;
}
